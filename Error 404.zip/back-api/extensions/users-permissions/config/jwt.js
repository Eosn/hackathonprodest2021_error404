module.exports = {
  jwtSecret: process.env.JWT_SECRET || '3fff9a28-f31c-422b-931b-48d471608953'
};
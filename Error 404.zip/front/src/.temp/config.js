export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Guia Cidadao",
  "siteUrl": "",
  "version": "0.7.23",
  "catchLinks": true
}
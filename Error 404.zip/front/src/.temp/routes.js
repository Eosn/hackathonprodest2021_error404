const c1 = () => import(/* webpackChunkName: "page--src-templates-article-vue" */ "D:\\Leo\\Estudos\\Hackatanga\\hackathon-cibercidadao-master\\src\\templates\\Article.vue")
const c2 = () => import(/* webpackChunkName: "page--src-pages-about-vue" */ "D:\\Leo\\Estudos\\Hackatanga\\hackathon-cibercidadao-master\\src\\pages\\About.vue")
const c3 = () => import(/* webpackChunkName: "page--node-modules-gridsome-app-pages-404-vue" */ "D:\\Leo\\Estudos\\Hackatanga\\hackathon-cibercidadao-master\\node_modules\\gridsome\\app\\pages\\404.vue")
const c4 = () => import(/* webpackChunkName: "page--src-pages-index-vue" */ "D:\\Leo\\Estudos\\Hackatanga\\hackathon-cibercidadao-master\\src\\pages\\Index.vue")

export default [
  {
    path: "/articles/1/",
    component: c1
  },
  {
    path: "/articles/2/",
    component: c1
  },
  {
    path: "/articles/3/",
    component: c1
  },
  {
    path: "/articles/4/",
    component: c1
  },
  {
    path: "/articles/5/",
    component: c1
  },
  {
    path: "/articles/6/",
    component: c1
  },
  {
    path: "/about/",
    component: c2
  },
  {
    name: "404",
    path: "/404/",
    component: c3
  },
  {
    name: "home",
    path: "/",
    component: c4
  },
  {
    name: "*",
    path: "*",
    component: c3
  }
]

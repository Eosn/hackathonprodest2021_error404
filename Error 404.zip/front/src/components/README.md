Add components that will be imported to Pages and Layouts to this folder.
Learn more about components here: https://gridsome.org/docs/components/

You can delete this file.
